<script lang='ts'>
	
	import Swiper from './SwipingApp.svelte';

</script>



<h1>Hello app!!</h1>

<div>
	<Swiper />
</div>