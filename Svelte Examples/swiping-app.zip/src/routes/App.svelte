<script lang='ts'>
	let name = $state('world');
	let count = $state(0);
	// https://svelte.dev/playground/f696ca27e6374f2cab1691727409a31d?version=5.53.2
	// https://svelte.dev/docs/svelte/animate
	
	import { useSwipe , type SwipeCustomEvent, tyoeGestureCustomEvent } from 'svelte-gestures';
	import Card from './Card.svelte';

  import { fade, fly, scale } from 'svelte/transition';
  let show = true;

	
	let direction = $state("none yet");
	let pointerType: string;

	let mx: number;
	let my: number;

	let target: HTMLElement | null;


	function swipeHandler(event: SwipeCustomEvent) {
		direction = event.detail.direction;
		pointerType = event.detail.pointerType;
		target = event.detail.target as HTMLElement;
		show = !show;
		
	}

	function moveHandler(event: GestureCustomEvent) {
		mx = event.detail.x;
		my = event.detail.y;
	}
	
</script>

<h1>Hello {name}!</h1>

<input bind:value={name} />
<button onclick={() => count += 1}>
	clicks: {count}
</button>


<section
	{...useSwipe(swipeHandler, () => ({ timeframe: 300, minSwipeDistance: 25, touchAction: 'none' }), {
		onswipemove: moveHandler
	})}
	class="box"
>
	<div class="content">
		<h2>Swipe Handler</h2>
		<div>swipe direction: {direction}</div>
		<div>pointerType {pointerType}</div>
		<div>target: {target?.tagName}</div>
		<h2>move</h2>
		<div>x: {mx}</div>
		<div>y: {my}</div>
	</div>



	
</section>	
{#if show}
	<div transition:fly={{ y: 100, duration: 700 }}>
		whoopdedoo
	</div>
{/if}

<h2> lets see how the animationBooleanWorks: {show}</h2>
<h1>Transition Demo</h1>
<Card />


<style>
	.content {
		user-select: none;
	}

	.box {
		border: 1px solid;
		padding:0.5rem;
	}
</style>