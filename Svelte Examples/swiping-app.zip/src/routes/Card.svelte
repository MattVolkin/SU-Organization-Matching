<script>
  import { fade, fly, scale } from 'svelte/transition';

  let show = true;
</script>

<button on:click={() => show = !show}>
  Toggle Elements
</button>

{#if show}
  <div transition:fly={{ x: 100, duration: 700 }}>
    <h1> Likeable </h1>
		<p> someone who is an enjoyable person to be around</p>
  </div>
{/if}

<div> adding this for spacing reasons: {show}</div>

<style>
	.content {
		user-select: none;
	}

	div {
		border: 1px solid;
		font-size: 12px;
		color: green;
	}

	.box {
		border: 1px solid;
		padding:0.5rem;
	}
</style>