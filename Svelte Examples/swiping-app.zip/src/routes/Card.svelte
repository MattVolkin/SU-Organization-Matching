<script>
  import { fade, fly, scale } from 'svelte/transition';

  let { show = true } = $props();
	let counter = $state(1);
	
	// list of items
	//https://svelte.dev/playground/805300f5895f4ea89b73ba75de393db8?version=5.53.6
	let items = $state([
		{id: 0, term: "Likable", def: "someone who is an enjoyable person to be around"},
		{id: 1, term: "Tired", def: "someone who has a lack of sleep"},
		{id: 2, term: "Happy", def: "State of euphoria"}

	]);

	
	let term = $state("empty");
	let def = $state("as always");	

	export function advanceCard( index = 0) {
		counter = index;
		counter %= items.length
		term = items[counter].term;
		def = items[counter].def;
		console.log("tried to advance card" + counter + ":" + term + ":" + def);
		
	}

</script>




<button onclick={() => show = !show}>
  Toggle Elements
</button>

  <div>
    <h1> {items[counter].term} </h1>
		<p> {items[counter].def}</p>
  </div>

<div> adding this for spacing reasons: {show}</div>

<style>
	.content {
		user-select: none;
	}

	div {
		border: 1px solid;
		font-size: 12px;
		color: red;
	}

	.box {
		border: 1px solid;
		padding:0.5rem;
		height:50%;

	}
</style>